# Inventory-App-Stage-1
My eighth project at Misk-Udacity- Android Basics by Google Nanodegree Program

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-1/blob/master/ScreenShots/1.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-1/blob/master/ScreenShots/2.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-1/blob/master/ScreenShots/3.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-1/blob/master/ScreenShots/4.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-1/blob/master/ScreenShots/5.png" height="600">
