package com.example.karim.ra4ad;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    //initalization Variables as globle Values
    int pointA = 0;
    int pointB = 0;

    //action added 3 point for teamA
    public void add_3_for_teamA(View view) {
        pointA = pointA + 3;
        displayA(pointA);
    }

    //action added 2 point for teamA
    public void add_2_for_teamA(View view) {
        pointA = pointA + 2;
        displayA(pointA);
    }

    //action added 1 point for teamA
    public void add_1_TeamA(View view) {
        pointA = pointA + 1;
        displayA(pointA);
    }

    //action added 3 point for teamB
    public void add_3_for_teamB(View view) {
        pointB = pointB + 3;
        displayB(pointB);
    }

    //action added 2 point for teamB
    public void add__for_teamB(View view) {
        pointB = pointB + 2;
        displayB(pointB);
    }

    //action added 1 point for teamB
    public void add_1_TeamB(View view) {
        pointB = pointB + 1;
        displayB(pointB);
    }


    private void displayA(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.teamA_score);
        quantityTextView.setText("" + number);
    }

    private void displayB(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.teamB_score);
        quantityTextView.setText("" + number);
    }

    // Reset  All points that done
    public void reset(View view) {
        pointA = 0;
        pointB = 0;

        displayA(pointB);
        displayB(pointB);
    }


}
