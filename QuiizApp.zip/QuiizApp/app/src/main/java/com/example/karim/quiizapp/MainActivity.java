package com.example.karim.quiizapp;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox liver_vs_real, liverVsBarca, realVsBayern,
            egyptian, algerian, moroccan;
    RadioButton chelsea, liverpool, russia,
            bTrue, manchesterFalse, kante, kane,
            italy, bFalse, manchesterTrue;
    EditText getText;
    int grade;
    int Full_Mark = 7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        chelsea = findViewById(R.id.radio_chelsea);
        liverpool = findViewById(R.id.radio_Liverpool);
        kante = findViewById(R.id.radio_Kante);
        kane = findViewById(R.id.radio_Kane);
        liver_vs_real = findViewById(R.id.liver_vs_real);
        liverVsBarca = findViewById(R.id.liver_vs_barca);
        realVsBayern = findViewById(R.id.real_vs_bayern);
        egyptian = findViewById(R.id.Eyptian);
        algerian = findViewById(R.id.Algerian);
        moroccan = findViewById(R.id.Moroccan);
        russia = findViewById(R.id.Russia);
        italy = findViewById(R.id.Italy);
        bTrue = findViewById(R.id.B_True);
        bFalse = findViewById(R.id.B_false);
        manchesterFalse = findViewById(R.id.Manchester_false);
        manchesterTrue = findViewById(R.id.Manchester_true);
        getText = findViewById(R.id.textName_feild);


    }


    public void Submit(View view) {
        String winMessage = finalMessageWin();
        String lostMessage = finalMessageLost();
        grade = checkResultCheckBox1() + checkResultCheckBox2() + checkResultRadioButton1()
                + checkResultRadioButton2() + checkResultRadioButton3() + checkResultRadioButton4()
                + checkResultRadioButton5();
        if (grade == Full_Mark) {
            setText(winMessage);
            Toast.makeText(this, " wow 😀  " + name() + "\n You Have Answered  " + grade + " Right Answers \n From 7 Question.", Toast.LENGTH_LONG).show();
        } else {
            setText(lostMessage);
            Toast.makeText(this, " Oh My god 😀 " + name() + "\n You Have Answered  " + grade + " Right Answers \n From 7 Question.", Toast.LENGTH_LONG).show();
        }

    }

    public void Finish(View view) {
        finish();
    }

    private int checkResultCheckBox1() {
        boolean realVsBayernChecked = realVsBayern.isChecked();
        boolean liverVsBarcaChecked = liverVsBarca.isChecked();
        boolean liverVsRealChecked = liver_vs_real.isChecked();
        if (liverVsRealChecked && !liverVsBarcaChecked && !realVsBayernChecked) {
            return 1;
        } else
            return 0;
    }

    private int checkResultCheckBox2() {
        boolean alegrianChecked = algerian.isChecked();
        boolean egyptianChecked = egyptian.isChecked();
        boolean moroccanChecked = moroccan.isChecked();
        if (!alegrianChecked && egyptianChecked && !moroccanChecked) {
            return 1;
        } else
            return 0;
    }

    private int checkResultRadioButton1() {
        boolean has_Chelsea_checked = chelsea.isChecked();
        if (has_Chelsea_checked) {
            return 1;
        } else
            return 0;
    }

    private int checkResultRadioButton2() {
        boolean hasKanteChecked = kante.isChecked();
        if (hasKanteChecked) {
            return 1;
        } else
            return 0;
    }

    private int checkResultRadioButton3() {
        boolean italyChecked = italy.isChecked();
        if (italyChecked) {
            return 1;
        } else
            return 0;
    }

    private int checkResultRadioButton4() {
        boolean bFalseChecked = bFalse.isChecked();
        if (bFalseChecked) {
            return 1;
        } else
            return 0;
    }

    private int checkResultRadioButton5() {

        boolean manchesterFalseChecked = manchesterFalse.isChecked();
        if (manchesterFalseChecked) {
            return 1;
        } else
            return 0;
    }

    private String name() {
        return getText.getText().toString();
    }

    private void setText(String Message) {
        TextView textView = findViewById(R.id.Final_Result);
        textView.setText(Message);

    }

    private String finalMessageWin() {
        String finalMessage = "You Win \uD83D\uDC4F\uD83D\uDE00\n";
        finalMessage += "ThankS :-" + name();
        return finalMessage;
    }

    private String finalMessageLost() {
        String finalMessage = "You lost\uD83D\uDE1F\uD83D\uDE1F\uD83D\uDE2D\uD83D\uDE2D\uD83D\uDE2D \n";
        finalMessage += "Plz Try Again !\n";
        finalMessage += "ThankS : " + name();
        return finalMessage;

    }

    public void Reset(View view) {
        getText.setText("");
        liver_vs_real.setChecked(false);
        realVsBayern.setChecked(false);
        liverVsBarca.setChecked(false);
        egyptian.setChecked(false);
        moroccan.setChecked(false);
        algerian.setChecked(false);
        liverpool.setChecked(false);
        chelsea.setChecked(false);
        kante.setChecked(false);
        bFalse.setChecked(false);
        bTrue.setChecked(false);
        manchesterFalse.setChecked(false);
        manchesterTrue.setChecked(false);
        russia.setChecked(false);
        italy.setChecked(false);

    }
}


