# News-App-Stage-1
My sixth project at Misk-Udacity- Android Basics by Google Nanodegree Program



<img src="https://github.com/Muneera-Salah/News-App-Stage-1/blob/master/screenshot/1.png" height="600">

<img src="https://github.com/Muneera-Salah/News-App-Stage-1/blob/master/screenshot/2.png" height="600">

<img src="https://github.com/Muneera-Salah/News-App-Stage-1/blob/master/screenshot/3.png" height="600">

<img src="https://github.com/Muneera-Salah/News-App-Stage-1/blob/master/screenshot/4.png" height="600">
