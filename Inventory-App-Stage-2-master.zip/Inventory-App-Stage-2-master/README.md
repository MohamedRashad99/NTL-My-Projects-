# Inventory-App-Stage-2
My ninth and the Last :) project at Misk-Udacity - Android Basics by Google Nanodegree Program

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/1.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/2.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/3.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/4.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/5.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/6.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/7.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/8.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/9.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/10.png" height="600">

<img src="https://github.com/Muneera-Salah/Inventory-App-Stage-2/blob/master/screenshots/Screenshot_2018-02-21-23-19-42.png" height="600">
